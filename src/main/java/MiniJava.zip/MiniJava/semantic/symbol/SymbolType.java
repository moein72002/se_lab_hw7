package MiniJava.semantic.symbol;

/**
 * Created by mohammad hosein on 6/28/2015.
 */

public enum SymbolType {
    Int, Bool
}
